package SPKI::Sexp;

use strict;
no strict 'vars';
use Carp;
use MIME::Base64;

# Since I can't find examples of s-exprs with display types their
# handling is untested.

# =========================================================================
# Internal functions
# =========================================================================

%backslash_map = (n => '\n', r => '\r');

foreach $char ("a".."z") {
  unless (defined $backslash_map{$char}) {
    $backslash_map{$char} = eval("\"\\" . $char . "\"");
  }
}

sub read_string_token {
  my $res;

  #print "Stringing: +$_+\n";
  if (/^\d/) {
    #print "byte-string\n";
    s/^(\d+):// or croak;
    my $len = 0 + $1;
    croak "String too short for bytes" unless (length >= $len);
    $res = substr($_, 0, $len);
    $_ = substr($_, $len);
  } elsif (/^\"/) {
    #print "quoted-string\n";
    s/^\"(([^\"\\]|\\.)*)\"// or croak "Can't match quoted string";
    $res = $1;
    $res =~ s/\\([a-z])/$backslash_map{$1}/eg;
    $res =~ tr/\\//d;
  } elsif (/^\#/) {
    #print "hex-string\n";
    s/^\#([0-9a-fA-F \t\n]*)\#// or croak "Can't match hex string";
    ($res = $1) =~ tr/ \t\n//d;
    croak unless (length($res) % 2 == 0);
    $res = pack("H*", $res);
  } elsif (/^\|/) {
    #print "base64-string\n";
    s/^\|([A-Za-z0-9 \t\n+=\/]*)\|// or croak "Can't match base64 string";
    $res = decode_base64($1);
  } else {
    #print "token\n";
    s/^([^\(\)\"\|\#\[\]\s]+)// or croak "Can't match token";
    $res = $1;
  }
  #$res or croak "didn't get a string";
  return $res;
}

sub to_readable_string {
  my ($indent, $bytes) = @_;

  if ($bytes =~ /^[A-Za-z_-][A-Za-z0-9_-]*$/) {
    # It's a token, return as is
    return $bytes;
  } elsif (!($bytes =~ tr/\0-\037\177-377//)) {
    # All printable characters, make a string
    $bytes =~ s/[\"\\]/\\$1/e;
    return "\"$bytes\"";
  } elsif (length($bytes) <= 20) {
    # Binary but short, use hex
    $bytes = unpack("H*", $bytes);
    $bytes =~ s/(.{8})/$1 /g;
    $bytes =~ s/ $//;
    return "#" . $bytes . "#";
  } else {
    # Binary and long, use base64.
    my $newi = $indent . " ";
    my $enc = encode_base64($bytes,'');
    my $len = 72 - length($newi);
    $len = 45 if ($len < 45);
    $len -= $len % 3;
    eval('$enc =~ s/(.{' . $len . '})/$1\n$newi/g');
    return "|" . $enc . "|";
  }
}

# =========================================================================
# Export candidates
# =========================================================================

sub string_to_sexp_list {
  my $proto = shift;
  my $class = ref($proto) || $proto;

  $_ = shift;
  my @res = ();
  my @stack = (\@res);

  # Remove white space.
  s/^\s*//;
  while ($_) {
    if (/^\(/) {
      #print "(\n";
      s/^\(//;
      unshift @stack, [];
    } elsif (/^\)/) {
      #print ")\n";
      croak "Too many closed parentheses" unless (@stack > 1);
      s/^\)//;
      my $top = shift @stack;
      push @{$stack[0]}, $proto->new_sexpr(@$top);
    } elsif (/^\{/) {
      #print "{\n";
      s/^\{([A-Za-z0-9+=\/ \t\n]*)\}// or croak "Bad base64 block";
      push @{$stack[0]}, string_to_sexp_list($proto, decode_base64($1));
    } else {
      my $dt;
      if (/^\[/) {
	s/^\[//;
	if (/^\d/) {
	  $dt = read_string_token();
	  s/^\]// or croak "Display type ends in wrong place";
	} else {
	  s/^([^\]]+)\]// or croak "Can't parse display type";
	  $dt = $1;
	}
      }
      push @{$stack[0]}, $proto->new_byte_string(read_string_token(), $dt);
    }
    # Remove white space.
    s/^\s*//;
  }
  croak "Too few closed parentheses" unless (@stack == 1);
  return @res;
}

sub sexperise_instance {
  my $in = shift;
  my $r = ref($in);
  if (!$r) {
    return SPKI::Sexp->new_byte_string($in);
  } elsif ($r eq "ARRAY") {
    return sexperise_list(@$in);
  } else {
    return $in;
  }
}

sub sexperise_list {
  SPKI::Sexp->new_sexpr(map {sexperise_instance($_)} @_);
}

# =========================================================================
# Object methods
# =========================================================================

sub new {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my @res = string_to_sexp_list($proto, shift);
  croak "Excactly one sexpr must be in string" unless (@res == 1);
  return $res[0];
}

sub new_sexpr {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $il = shift;
  my %emap;
  my $self = {initial => $il, spart => [ @_ ], emap => \%emap};
  if ($il->is_sexpr()) {
    croak "First element in s-expr must be byte_string";
  }
  foreach $e (@_) {
    my $in = $e->{initial};
    if (defined $in) {
      $inn = $in->{bytes};
      #print "Adding +$inn+\n";
      push @{$emap{$inn}}, $e;
    }
  }
  bless($self, $class);
  return $self;
}

sub new_byte_string {
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $bytes = shift;
  $self = { bytes => $bytes };
  $self->{displaytype} = shift if (@_ and defined $_[0]);
  bless($self, $class);
  return $self;
}

sub is_sexpr {defined shift->{initial}}
sub bytes {shift->{bytes}}
sub displaytype {shift->{displaytype}}
sub initial {shift->{initial}}
sub spart {@{shift->{spart}}}

sub elements {
  my $self = shift;
  return ( $self->{'initial'}, @{$self->{'spart'}});
}

sub elt_list {
  my ($self, $initial) = @_;
  #print "Looking up +$initial+\n";
  my $ar = $self->{emap}->{$initial};
  return $ar ? @$ar : ();
}

sub elt {
  my @elist = elt_list(@_);
  croak "S-expr doesn't contain exactly one of those" unless (1 == @elist);
  return $elist[0];
}

sub to_canon {
  my $self = shift;
  if ($self->is_sexpr()) {
    return join("", "(",  ( map {$_->to_canon()} $self->elements() ), ")");
  } else {
    my $bytes = $self->bytes();
    #print "canonicalising: +$bytes+\n";
    my $lbytes = length($bytes) . ":" . $bytes;
    my $displaytype = $self->displaytype();

    if (defined $displaytype) {
      return '[' . length($displaytype) . ":" . $displaytype . ']'. $lbytes;
    } else {
      return $lbytes;
    }
  }
}

sub to_base64 {
  my $enc = encode_base64(shift->to_canon());
  $enc =~ s/\s*$//;
  return '{' . $enc . '}';
}

sub to_readable_i {
  my ($self, $indent) = @_;
  if ($self->is_sexpr()) {
    my $newi = $indent . " ";

    return "(" . 
      join("\n$newi", 
	   ( map {$_->to_readable_i($newi)} $self->elements() ) ) .
	     ")";
  } else {
    my $dt = $self->displaytype();
    if( defined $dt ) {
      return '[' . $dt . ']' . 
	to_readable_string($indent, $self->bytes());
    } else {
      return to_readable_string($indent, $self->bytes());
    }
  }
}

sub to_readable {
  return (shift)->to_readable_i("") . "\n";
}

# =========================================================================

1;
__END__
